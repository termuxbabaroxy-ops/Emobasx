package com.example.baskomutu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.content.Context
import android.os.Bundle
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.sin

class ListeningService : Service() {
    companion object { const val EXTRA_WORD = "trigger_word"; private const val CHANNEL = "bas_komutu_channel"; private const val NOTIF_ID = 1001 }
    private var recognizer: SpeechRecognizer? = null
    private var triggerWord = "basla"
    @Volatile private var active = false
    @Volatile private var playing = false
    private var track: AudioTrack? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastTrigger = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        triggerWord = (intent?.getStringExtra(EXTRA_WORD) ?: triggerWord).lowercase(Locale("tr", "TR"))
        createChannel()
        startForeground(NOTIF_ID, notification("Komut bekleniyor: $triggerWord"))
        if (!active) {
            active = true
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BasKomutu:Listening").apply { acquire() }
            beginRecognition()
        }
        return START_STICKY
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Bas Komutu", NotificationManager.IMPORTANCE_LOW).apply { description = "Sesle tetiklenen bas oynatımı" })
        }
    }
    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, StopServiceReceiver::class.java).setAction("STOP_LISTENING"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return b.setContentTitle("Bas Komutu").setContentText(text).setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, "Durdur", stop).setOngoing(true).build()
    }
    private fun beginRecognition() {
        if (!active || playing) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        try {
            if (recognizer == null) recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { updateNotification("Dinliyor: $triggerWord") }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { scheduleRecognition() }
                    override fun onError(error: Int) { scheduleRecognition() }
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                        val found = matches.any { normalize(it).contains(normalize(triggerWord)) }
                        if (found && System.currentTimeMillis() - lastTrigger > 2500) {
                            lastTrigger = System.currentTimeMillis(); playBass()
                        }
                        scheduleRecognition()
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                        if (matches.any { normalize(it).contains(normalize(triggerWord)) } && System.currentTimeMillis() - lastTrigger > 2500) {
                            lastTrigger = System.currentTimeMillis(); playBass()
                        }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            recognizer?.startListening(i)
        } catch (_: Exception) { scheduleRecognition() }
    }
    private fun normalize(s: String) = s.lowercase(Locale("tr", "TR")).replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c')
    private fun scheduleRecognition() {
        if (!active || playing) return
        android.os.Handler(mainLooper).postDelayed({ if (active && !playing) beginRecognition() }, 700)
    }
    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, notification(text))
    }
    private fun playBass() {
        if (playing) return
        playing = true
        try { recognizer?.cancel() } catch (_: Exception) {}
        updateNotification("Bas sesi çalıyor")
        thread(name = "BassTone") {
            try {
                val sampleRate = 44100
                val seconds = 2.5
                val count = (sampleRate * seconds).toInt()
                val samples = ShortArray(count)
                for (n in 0 until count) {
                    val t = n.toDouble() / sampleRate
                    val fadeIn = (t / 0.025).coerceIn(0.0, 1.0)
                    val fadeOut = ((seconds - t) / 0.18).coerceIn(0.0, 1.0)
                    val envelope = minOf(fadeIn, fadeOut)
                    val fundamental = sin(2.0 * PI * 55.0 * t)
                    val harmonic = sin(2.0 * PI * 110.0 * t) * 0.20
                    samples[n] = ((fundamental + harmonic) * 0.48 * envelope * Short.MAX_VALUE).toInt().toShort()
                }
                val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                val fmt = AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val a = AudioTrack.Builder().setAudioAttributes(attrs).setAudioFormat(fmt).setBufferSizeInBytes(maxOf(min, samples.size * 2)).setTransferMode(AudioTrack.MODE_STATIC).build()
                track = a
                a.write(samples, 0, samples.size)
                a.play()
                Thread.sleep((seconds * 1000).toLong() + 150)
                a.stop(); a.release(); track = null
            } catch (_: Exception) { try { track?.release() } catch (_: Exception) {}; track = null }
            playing = false
            if (active) { updateNotification("Komut bekleniyor: $triggerWord"); scheduleRecognition() }
        }
    }
    override fun onDestroy() {
        active = false
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        try { track?.stop(); track?.release() } catch (_: Exception) {}
        track = null
        try { wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
