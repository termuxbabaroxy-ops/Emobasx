package com.example.baskomutu

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var keyword: EditText
    private val reqCode = 41
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18,20,38)
        window.navigationBarColor = Color.rgb(18,20,38)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(28, 30, 28, 30); setBackgroundColor(Color.rgb(18,20,38))
        }
        root.addView(TextView(this).apply {
            text = "BAS KOMUTU"; textSize = 28f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }, match())
        root.addView(TextView(this).apply {
            text = "Komut kelimesini söyle, bas sesi başlasın."; textSize = 16f
            setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0,16,0,22)
        }, match())
        keyword = EditText(this).apply {
            setSingleLine(true); setText("Basla"); hint = "Komut kelimesi"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setPadding(16, 12, 16, 12); setBackgroundColor(Color.rgb(38,41,65))
        }
        root.addView(keyword, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 56).apply { bottomMargin = 16 })
        val start = Button(this).apply { text = "DİNLEMEYİ BAŞLAT"; setOnClickListener { requestAndStart() } }
        root.addView(start, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 58).apply { bottomMargin = 10 })
        root.addView(Button(this).apply {
            text = "DİNLEMEYİ DURDUR"
            setOnClickListener { stopService(Intent(this@MainActivity, ListeningService::class.java)); status.text = "Dinleme kapalı" }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 54))
        status = TextView(this).apply {
            text = "Hazır — dinlemeyi başlatmak için dokun."; textSize = 14f
            setTextColor(Color.rgb(180,185,210)); gravity = Gravity.CENTER; setPadding(0,24,0,0)
        }
        root.addView(status, match())
        root.addView(TextView(this).apply {
            text = "Not: Konuşma tanıma Android'in konuşma hizmetine bağlıdır.\nBas sesi telefon hoparlörünün fiziksel kapasitesiyle sınırlıdır."
            textSize = 12f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setPadding(0,30,0,0)
        }, match())
        setContentView(root)
    }
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun requestAndStart() {
        val word = keyword.text.toString().trim()
        if (word.isBlank()) { Toast.makeText(this, "Bir komut kelimesi yaz.", Toast.LENGTH_SHORT).show(); return }
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), reqCode); return }
        startListening(word)
    }
    private fun startListening(word: String) {
        val i = Intent(this, ListeningService::class.java).putExtra(ListeningService.EXTRA_WORD, word)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
        status.text = "Dinliyor: “$word” — arka planda sürer."
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqCode && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startListening(keyword.text.toString().trim())
        } else Toast.makeText(this, "Dinlemek için mikrofon izni gerekli.", Toast.LENGTH_LONG).show()
    }
}
