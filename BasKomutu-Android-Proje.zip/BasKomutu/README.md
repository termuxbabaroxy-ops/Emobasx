# Bas Komutu (Android)

Android için Kotlin tabanlı başlangıç projesi. Kullanıcı uygulamayı açıp mikrofon izni verdikten sonra bir komut kelimesi seçer; Türkçe konuşma tanıma bu kelimeyi duyduğunda yaklaşık 55 Hz temel frekanslı kısa bas tonu üretir. Mikrofon dinlemesi, Android ön plan hizmeti ve devam eden bildirim üzerinden yürütülür.

## Derleme
- Android Studio (Giraffe veya daha yeni)
- Android SDK 35
- JDK 17

Projeyi Android Studio'da açıp Gradle eşitlemesini tamamlayın ve bir Android cihaza çalıştırın. Bu ortamda Android SDK/Gradle ile derleme yapılmadı; APK dosyası dahil değildir.

## Sınırlamalar
- Kelime algılama, cihazdaki Android konuşma tanıma hizmetine bağlıdır; hizmet yoksa veya üretici arka planı kısıtlarsa sürekli dinleme garanti edilemez.
- Android 12+ pil yönetimi ve Android 14+ mikrofon ön plan hizmeti kuralları geçerlidir. Dinlemeyi uygulamadan veya bildirimden durdurun.
- Bu bir test/başlangıç projesidir; her cihazda çalıştığı doğrulanmış yayımlanmış uygulama değildir.
